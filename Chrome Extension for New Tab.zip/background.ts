// Check every 10 seconds for a new tab page
const CHECK_INTERVAL = 10000; // 10 seconds in milliseconds

function checkForNewTab() {
  chrome.tabs.query({}, (tabs) => {
    // Check if any tab is a new tab page
    const hasNewTab = tabs.some(tab =>
      tab.url === 'chrome://newtab/' ||
      tab.pendingUrl === 'chrome://newtab/'
    );

    if (!hasNewTab) {
      // No new tab exists, create one
      chrome.tabs.create({ url: 'chrome://newtab/' });
    }
  });
}

// Start checking when the extension is installed or reloaded
chrome.runtime.onInstalled.addListener(() => {
  checkForNewTab();
  setInterval(checkForNewTab, CHECK_INTERVAL);
});

// Also start checking when the service worker starts
checkForNewTab();
setInterval(checkForNewTab, CHECK_INTERVAL);
