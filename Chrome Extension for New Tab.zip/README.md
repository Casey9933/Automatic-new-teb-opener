
  # Chrome Extension for New Tab

  This is a code bundle for Chrome Extension for New Tab. The original project is available at https://www.figma.com/design/sPyLKFjCHVHt4wIRbCBo4K/Chrome-Extension-for-New-Tab.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  